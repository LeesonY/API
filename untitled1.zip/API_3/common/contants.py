#-*- coding: utf-8 -*-

import os

base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))# API_3
print(base_dir)

case_file = os.path.join(base_dir,'data','case.xlsx')
print(case_file)













